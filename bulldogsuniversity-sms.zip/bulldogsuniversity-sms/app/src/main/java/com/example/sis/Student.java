package com.example.sis;

public class Student {
    public String studentNo, lastName, firstName, middleName, college, program, yearLevel;

    public Student(String studentNo, String lastName, String firstName, String middleName,
                   String college, String program, String yearLevel) {
        this.studentNo = studentNo;
        this.lastName = lastName;
        this.firstName = firstName;
        this.middleName = middleName;
        this.college = college;
        this.program = program;
        this.yearLevel = yearLevel;
    }

    /** "Last, First Middle" */
    public String fullName() {
        String m = (middleName == null || middleName.isEmpty()) ? "" : " " + middleName;
        return lastName + ", " + firstName + m;
    }
}
