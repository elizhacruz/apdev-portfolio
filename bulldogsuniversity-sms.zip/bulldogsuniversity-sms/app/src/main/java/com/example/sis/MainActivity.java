package com.example.sis;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private DBHelper db;
    private ListView list;
    private TextView tvEmpty, tvCount;
    private EditText etSearch;
    private final List<Student> students = new ArrayList<>();
    private ArrayAdapter<Student> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        db = new DBHelper(this);

        list = findViewById(R.id.listStudents);
        tvEmpty = findViewById(R.id.tvEmpty);
        tvCount = findViewById(R.id.tvCount);
        etSearch = findViewById(R.id.etSearch);
        ((TextView) findViewById(R.id.tvWelcome)).setText(
                "Student Information System  |  " + getIntent().getStringExtra("username"));

        adapter = new ArrayAdapter<Student>(this, R.layout.item_student, students) {
            @Override
            public View getView(int pos, View convert, ViewGroup parent) {
                if (convert == null) {
                    convert = getLayoutInflater().inflate(R.layout.item_student, parent, false);
                }
                Student s = getItem(pos);
                ((TextView) convert.findViewById(R.id.tvNo)).setText(s.studentNo);
                ((TextView) convert.findViewById(R.id.tvYear)).setText(s.yearLevel);
                ((TextView) convert.findViewById(R.id.tvName)).setText(s.fullName());
                ((TextView) convert.findViewById(R.id.tvProgram)).setText(s.program);
                ((TextView) convert.findViewById(R.id.tvCollege)).setText(s.college);
                return convert;
            }
        };
        list.setAdapter(adapter);

        list.setOnItemClickListener((p, v, pos, id) -> {
            Intent i = new Intent(this, StudentFormActivity.class);
            i.putExtra("student_no", students.get(pos).studentNo);
            startActivity(i);
        });

        ((FloatingActionButton) findViewById(R.id.fabAdd)).setOnClickListener(v ->
                startActivity(new Intent(this, StudentFormActivity.class)));

        findViewById(R.id.btnLogout).setOnClickListener(v -> {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        });

        etSearch.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            public void onTextChanged(CharSequence s, int a, int b, int c) { refresh(); }
            public void afterTextChanged(Editable s) {}
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    private void refresh() {
        students.clear();
        students.addAll(db.searchStudents(etSearch.getText().toString().trim()));
        adapter.notifyDataSetChanged();
        tvEmpty.setVisibility(students.isEmpty() ? View.VISIBLE : View.GONE);
        tvCount.setText(students.size() + (students.size() == 1 ? " student" : " students"));
    }
}
