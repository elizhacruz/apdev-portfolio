package com.example.sis;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** All programs, organized by college (used by the dropdowns). */
public final class Programs {
    public static final Map<String, List<String>> BY_COLLEGE = new LinkedHashMap<>();
    public static final List<String> YEAR_LEVELS = Arrays.asList(
            "1st Year", "2nd Year", "3rd Year", "4th Year", "5th Year");

    private static void add(String college, String... programs) {
        List<String> list = BY_COLLEGE.get(college);
        if (list == null) { list = new ArrayList<>(); BY_COLLEGE.put(college, list); }
        list.addAll(Arrays.asList(programs));
    }

    static {
        add("College of Allied Health",
                "BS Nursing",
                "BS Medical Technology / Medical Laboratory Science",
                "BS Pharmacy");
        add("College of Architecture, Planning, and Sustainable Built Environment",
                "BS Environmental Planning",
                "BS Architecture");
        add("College of Business and Accountancy",
                "BS Accountancy",
                "BS Management Accounting",
                "BS Business Administration - major in Financial Management",
                "BS Business Administration - major in Marketing Management",
                "BS Business Administration - major in Human Resource Management");
        add("College of Computing and Information Technologies",
                "BS Computer Science - specialization in Digital Forensics",
                "BS Computer Science - specialization in Machine Learning",
                "BS Information Technology - specialization in Mobile and Web Applications",
                "BS Information Technology - specialization in Multimedia Arts and Animation",
                "Associate in Computer Technology");
        add("College of Education, Arts, and Sciences",
                "AB English Language Studies",
                "AB Communication",
                "AB Political Science",
                "BS Psychology",
                "Bachelor of Elementary Education",
                "Bachelor of Secondary Education - major in English",
                "Bachelor of Physical Education",
                "Certificate in Professional Education");
        add("College of Engineering",
                "BS Civil Engineering",
                "BS Computer Engineering",
                "BS Electrical Engineering",
                "BS Electronics Engineering",
                "BS Mechanical Engineering",
                "BS Environmental and Sanitary Engineering");
        add("College of Tourism and Hospitality Management",
                "BS Hospitality Management",
                "BS Tourism Management");
    }

    private Programs() {}
}
