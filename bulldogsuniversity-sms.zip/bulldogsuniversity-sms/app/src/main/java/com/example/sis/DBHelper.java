package com.example.sis;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.List;

public class DBHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "sis.db";
    private static final int DB_VERSION = 1;

    public DBHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE users (username TEXT PRIMARY KEY, password TEXT NOT NULL)");
        db.execSQL("CREATE TABLE students (" +
                "student_no TEXT PRIMARY KEY, last_name TEXT NOT NULL, first_name TEXT NOT NULL, " +
                "middle_name TEXT, college TEXT NOT NULL, program TEXT NOT NULL, " +
                "year_level TEXT NOT NULL)");
        ContentValues cv = new ContentValues();
        cv.put("username", "admin");
        cv.put("password", hash("admin123"));
        db.insert("users", null, cv);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldV, int newV) {
        db.execSQL("DROP TABLE IF EXISTS students");
        db.execSQL("DROP TABLE IF EXISTS users");
        onCreate(db);
    }

    static String hash(String s) {
        try {
            byte[] d = MessageDigest.getInstance("SHA-256").digest(s.getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (byte b : d) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) {
            return s;
        }
    }

    public boolean checkLogin(String username, String password) {
        SQLiteDatabase db = getReadableDatabase();
        try (Cursor c = db.rawQuery("SELECT 1 FROM users WHERE username=? AND password=?",
                new String[]{username, hash(password)})) {
            return c.moveToFirst();
        }
    }

    private ContentValues toValues(Student s) {
        ContentValues cv = new ContentValues();
        cv.put("student_no", s.studentNo);
        cv.put("last_name", s.lastName);
        cv.put("first_name", s.firstName);
        cv.put("middle_name", s.middleName);
        cv.put("college", s.college);
        cv.put("program", s.program);
        cv.put("year_level", s.yearLevel);
        return cv;
    }

    /** @return false if the student number already exists. */
    public boolean addStudent(Student s) {
        return getWritableDatabase().insert("students", null, toValues(s)) != -1;
    }

    public boolean updateStudent(Student s) {
        return getWritableDatabase().update("students", toValues(s),
                "student_no=?", new String[]{s.studentNo}) > 0;
    }

    public boolean deleteStudent(String studentNo) {
        return getWritableDatabase().delete("students", "student_no=?",
                new String[]{studentNo}) > 0;
    }

    private Student fromCursor(Cursor c) {
        return new Student(c.getString(0), c.getString(1), c.getString(2), c.getString(3),
                c.getString(4), c.getString(5), c.getString(6));
    }

    public Student getStudent(String studentNo) {
        try (Cursor c = getReadableDatabase().rawQuery(
                "SELECT * FROM students WHERE student_no=?", new String[]{studentNo})) {
            return c.moveToFirst() ? fromCursor(c) : null;
        }
    }

    public List<Student> searchStudents(String q) {
        List<Student> list = new ArrayList<>();
        String like = "%" + q + "%";
        try (Cursor c = getReadableDatabase().rawQuery(
                "SELECT * FROM students WHERE student_no LIKE ? OR last_name LIKE ? " +
                        "OR first_name LIKE ? OR middle_name LIKE ? " +
                        "ORDER BY last_name, first_name",
                new String[]{like, like, like, like})) {
            while (c.moveToNext()) list.add(fromCursor(c));
        }
        return list;
    }
}
