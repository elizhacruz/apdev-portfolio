package com.example.sis;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class StudentFormActivity extends AppCompatActivity {
    private DBHelper db;
    private EditText etNo, etLast, etFirst, etMiddle;
    private Spinner spCollege, spProgram, spYear;
    private final List<String> colleges = new ArrayList<>(Programs.BY_COLLEGE.keySet());
    private String pendingProgram = null;   // program to preselect when editing
    private String editingNo = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_form);
        db = new DBHelper(this);

        etNo = findViewById(R.id.etStudentNo);
        etLast = findViewById(R.id.etLastName);
        etFirst = findViewById(R.id.etFirstName);
        etMiddle = findViewById(R.id.etMiddleName);
        spCollege = findViewById(R.id.spCollege);
        spProgram = findViewById(R.id.spProgram);
        spYear = findViewById(R.id.spYear);

        spCollege.setAdapter(new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item, colleges));
        spYear.setAdapter(new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item, Programs.YEAR_LEVELS));

        // Program list depends on the selected college
        spCollege.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                List<String> programs = Programs.BY_COLLEGE.get(colleges.get(pos));
                spProgram.setAdapter(new ArrayAdapter<>(StudentFormActivity.this,
                        android.R.layout.simple_spinner_dropdown_item, programs));
                if (pendingProgram != null) {
                    int i = programs.indexOf(pendingProgram);
                    if (i >= 0) spProgram.setSelection(i);
                    pendingProgram = null;
                }
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });

        editingNo = getIntent().getStringExtra("student_no");
        if (editingNo != null) {
            Student s = db.getStudent(editingNo);
            if (s != null) {
                ((TextView) findViewById(R.id.tvFormTitle)).setText("Edit Student");
                etNo.setText(s.studentNo);
                etNo.setEnabled(false);          // student no. is the unique key
                etLast.setText(s.lastName);
                etFirst.setText(s.firstName);
                etMiddle.setText(s.middleName);
                pendingProgram = s.program;
                spCollege.setSelection(colleges.indexOf(s.college));
                spYear.setSelection(Programs.YEAR_LEVELS.indexOf(s.yearLevel));
                findViewById(R.id.btnDelete).setVisibility(View.VISIBLE);
            }
        }

        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
        findViewById(R.id.btnSave).setOnClickListener(v -> save());
        findViewById(R.id.btnDelete).setOnClickListener(v ->
                new AlertDialog.Builder(this)
                        .setTitle("Delete student?")
                        .setMessage("This cannot be undone.")
                        .setPositiveButton("Delete", (d, w) -> {
                            db.deleteStudent(editingNo);
                            finish();
                        })
                        .setNegativeButton("Cancel", null)
                        .show());
    }

    private void save() {
        String no = etNo.getText().toString().trim();
        String last = etLast.getText().toString().trim();
        String first = etFirst.getText().toString().trim();
        String middle = etMiddle.getText().toString().trim();

        if (no.isEmpty() || last.isEmpty() || first.isEmpty()) {
            Toast.makeText(this, "Student no., last name and first name are required",
                    Toast.LENGTH_SHORT).show();
            return;
        }
        if (spProgram.getSelectedItem() == null) return;

        Student s = new Student(no, last, first, middle,
                (String) spCollege.getSelectedItem(),
                (String) spProgram.getSelectedItem(),
                (String) spYear.getSelectedItem());

        boolean ok = (editingNo == null) ? db.addStudent(s) : db.updateStudent(s);
        if (ok) {
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            Toast.makeText(this, "Student no. already exists", Toast.LENGTH_SHORT).show();
        }
    }
}
